import sys
from pathlib import Path
file = Path(__file__).resolve()
parent, root = file.parent, file.parents[1]
sys.path.append(str(root))

from typing import List, Optional, Tuple, Union

from datetime import datetime
import numpy as np
import pandas as pd
from pydantic import BaseModel, ValidationError, Field

from laptop_sales_model.config.core import config



def validate_inputs(*, input_df: pd.DataFrame) -> Tuple[pd.DataFrame, Optional[dict]]:
    """Check model inputs for unprocessable values."""

    pre_processed =  input_df
    validated_data = pre_processed[config.model_config.features].copy()
    errors = None

    try:
        # replace numpy nans so that pydantic can validate
        MultipleDataInputs(
            inputs = validated_data.replace({np.nan: None}).to_dict(orient="records")
        )
    except ValidationError as error:
        errors = error.json()

    return validated_data, errors


class DataInputSchema(BaseModel):
    make: Optional[str] = Field(None, alias="Make")
    colour: Optional[str] = Field(None, alias="Colour")
    usage_hours: Optional[int] = Field(None, alias="Usage (Hours)")
    usb_ports: Optional[int] = Field(None, alias="USB Ports")

    class Config:
        # Allow population by field name or alias
        allow_population_by_field_name = True

class MultipleDataInputs(BaseModel):
    inputs: List[DataInputSchema]